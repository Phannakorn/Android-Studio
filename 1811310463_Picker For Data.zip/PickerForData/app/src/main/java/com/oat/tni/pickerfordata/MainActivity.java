package com.oat.tni.pickerfordata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showDatePiker(View view) {
        DialogFragment newFrangment = new DatePickerFrangment();
        newFrangment.show(getSupportFragmentManager(),getString(R.string.text_showdatepicker));
    }

    public void processDatePickerResult(int year, int month, int dayOfMonth) {
        String month_string = Integer.toString(month+1);
        String day_string = Integer.toString(dayOfMonth);
        String year_string = Integer.toString(year);
        String dateMessage = (month_string + "/" + day_string + "/" + year_string);

        Toast.makeText(this,getString(R.string.date) + dateMessage,
                Toast.LENGTH_SHORT).show();
    }

}

