package com.oat.tni.simpleasynctask;

import android.os.AsyncTask;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.net.CookieHandler;
import java.util.Random;


public  class  SimpleAsyncTask  extends AsyncTask<Void, Integer, String> {
    private WeakReference<TextView> mTextView;
    SimpleAsyncTask(TextView tv) {
        mTextView = new WeakReference<>(tv);
    }

    @Override
    protected String doInBackground(Void... voids) {
        Random r = new Random();
        int n = r.nextInt(11);
        int s = n * 200;
        int j = s/100 ;
        for (int i=0 ; i<j ; i++) {
            try {
                Thread.sleep(1);
                publishProgress(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return "Awake at last after sleeping for " + s + " milliseconds!";
    }

    @Override
    protected void onProgressUpdate(Integer... i) {
        super.onProgressUpdate(i);
        mTextView.get().setText("Reamaining..."+i[0]*100 + " milliseconds!");
        }


    protected void onPostExecute(String result) {
        mTextView.get().setText(result);
    }
}
