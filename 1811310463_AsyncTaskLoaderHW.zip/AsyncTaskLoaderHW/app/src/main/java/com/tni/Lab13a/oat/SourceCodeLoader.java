package com.tni.Lab13a.Lab13aHomeWork;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;

public class SourceCodeLoader extends AsyncTaskLoader<String> {
    private String mProtocol;
    private String mQueryString;

    public SourceCodeLoader(@NonNull Context context, String protocol, String queryString) {
        super(context);
        mProtocol = protocol;
        mQueryString = queryString;
    }

    @Nullable
    @Override
    public String loadInBackground() {
        return NetworkUtils.getWWWInfo(mProtocol, mQueryString);
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }
}
