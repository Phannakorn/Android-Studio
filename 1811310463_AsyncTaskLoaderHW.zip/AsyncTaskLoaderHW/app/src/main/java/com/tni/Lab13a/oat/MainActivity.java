package com.tni.Lab13a.Lab13aHomeWork;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String>, AdapterView.OnItemSelectedListener {
    private EditText mWWWInput;
    private TextView mTextView;
    String spinnerLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWWWInput = findViewById(R.id.url_EditText);
        mTextView = findViewById(R.id.page_source_code);
        Spinner spinner = findViewById(R.id.http_spinner);

        if (spinner != null) {
            spinner.setOnItemSelectedListener(this);
        }

        // Create ArrayAdapter using the string array and default spinner layout.
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.http_array, android.R.layout.simple_spinner_item);

        // Specify the layout to use when the list of choices appears.
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner.
        if (spinner != null) {
            spinner.setAdapter(adapter);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinnerLabel = parent.getItemAtPosition(position).toString();
        displayToast(spinnerLabel);
    }

    private void displayToast(String ms) {
        Toast.makeText(getApplicationContext(), ms,
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String queryString = "";
        if (args != null) {
            queryString = args.getString("queryString");
        }
        return new SourceCodeLoader(this, spinnerLabel, queryString);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        if(data != null){
            mTextView.setText(data);
        }
        else{
            mTextView.setText(R.string.no_response);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void GetSource(View view) {
        // Get the search string from the input field.
        String queryString = mWWWInput.getText().toString();
        InputMethodManager inputManager =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputManager != null) {
            inputManager.hideSoftInputFromWindow(view.getWindowToken(),
                    InputMethodManager.HIDE_NOT_ALWAYS);
        }

        ConnectivityManager cm =

                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        boolean hasInternet = false;
        if (cm != null) {
            Network[] networks = cm.getAllNetworks();
            for (Network nw : networks) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(nw);
                if (nc != null)
                    if (nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                        hasInternet = true;

            }
        }
        // If the network is available, connected, and the search field is not empty,
        // start a FetchBook AsyncTask.
        if (hasInternet && queryString.length() != 0) {
            Bundle queryBundle = new Bundle();
            queryBundle.putString("queryString", queryString);
            getSupportLoaderManager().restartLoader(0, queryBundle, this);
            mTextView.setText(R.string.loading);
        }

        // Otherwise update the TextView to tell the user there is no connection,
        // or no search term.
        else {
            if (queryString.length() == 0) {
                mTextView.setText(R.string.no_url);
            } else {
                mTextView.setText(R.string.no_connection);
            }
        }
    }
}
